<?php
// add_product.php
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Tambah Produk</title>
    <style>
        body { font-family: Arial, sans-serif; }
        .container { max-width: 500px; margin: auto; padding: 20px; }
        label { display: block; margin-top: 10px; }
        input[type="text"],
        input[type="number"] { width: 100%; padding: 8px; box-sizing: border-box; }
        button { margin-top: 15px; padding: 10px 20px; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Tambah Produk Baru</h2>
        <form action="process_add_product.php" method="POST">
            <label for="plu">Kode PLU:</label>
            <input type="text" id="plu" name="plu" required>
            
            <label for="name">Nama Produk:</label>
            <input type="text" id="name" name="name" required>
            
            <label for="price">Harga (misal: 15000.00):</label>
            <input type="number" id="price" name="price" step="0.01" required>
            
            <label for="stock">Stok:</label>
            <input type="number" id="stock" name="stock" min="0" required>
            
            <button type="submit">Simpan Produk</button>
        </form>
        <br>
        <a href="transaction.php">Kembali ke Halaman Transaksi</a>
    </div>
</body>
</html>
