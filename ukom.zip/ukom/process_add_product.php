<?php
// process_add_product.php
include 'koneksi.php';

// Ambil data dari form
$plu   = trim($_POST['plu']);
$name  = trim($_POST['name']);
$price = trim($_POST['price']);
$stock = trim($_POST['stock']);

// Validasi sederhana
if(empty($plu) || empty($name) || empty($price) || empty($stock)) {
    echo "<script>alert('Semua data harus diisi!'); window.location='add_product.php';</script>";
    exit;
}

// Periksa apakah kode PLU sudah terdaftar
$sql_check = "SELECT * FROM products WHERE plu='$plu'";
$result = $koneksi->query($sql_check);
if ($result->num_rows > 0) {
    echo "<script>alert('Kode PLU sudah ada, silakan gunakan kode lain!'); window.location='add_product.php';</script>";
    exit;
}

// Query untuk memasukkan data produk ke database
$sql = "INSERT INTO products (plu, name, price, stock) VALUES ('$plu', '$name', '$price', '$stock')";

if ($koneksi->query($sql) === TRUE) {
    echo "<script>alert('Produk berhasil ditambahkan!'); window.location='add_product.php';</script>";
} else {
    echo "Terjadi kesalahan: " . $koneksi->error;
}

$koneksi->close();
?>
