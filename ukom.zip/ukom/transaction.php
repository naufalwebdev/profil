<?php
session_start();
include 'koneksi.php';

// Inisialisasi cart di session jika belum ada
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

// Jika form PLU disubmit
if (isset($_POST['plu'])) {
    $plu = $_POST['plu'];

    // Cek di database apakah PLU ada
    $sql = "SELECT * FROM products WHERE plu = '$plu' LIMIT 1";
    $result = $koneksi->query($sql);

    if ($result->num_rows > 0) {
        $product = $result->fetch_assoc();

        // Tanyakan berapa jumlah yang dibeli
        // Untuk contoh sederhana, langsung arahkan ke form input quantity
        $_SESSION['selected_product'] = $product; 
        header("Location: transaction_quantity.php");
        exit;
    } else {
        echo "<script>alert('PLU tidak ditemukan.');</script>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Transaksi</title>
</head>
<body>
    <h2>Transaksi Penjualan</h2>
    <!-- Form input Kode PLU -->
    <form action="" method="POST">
        <label>Masukkan Kode PLU Produk:</label><br>
        <input type="text" name="plu" required>
        <button type="submit">Cek Produk</button>
    </form>

    <br><hr><br>
    <!-- Tampilkan isi keranjang -->
    <h3>Keranjang Belanja</h3>
    <table border="1" cellpadding="5" cellspacing="0">
        <tr>
            <th>PLU</th>
            <th>Nama Produk</th>
            <th>Harga</th>
            <th>Jumlah</th>
            <th>Sub Total</th>
        </tr>
        <?php
        $grandTotal = 0;
        foreach ($_SESSION['cart'] as $item) {
            $subTotal = $item['price'] * $item['quantity'];
            $grandTotal += $subTotal;
            ?>
            <tr>
                <td><?php echo $item['plu']; ?></td>
                <td><?php echo $item['name']; ?></td>
                <td><?php echo number_format($item['price'], 2); ?></td>
                <td><?php echo $item['quantity']; ?></td>
                <td><?php echo number_format($subTotal, 2); ?></td>
            </tr>
        <?php } ?>
        <tr>
            <td colspan="4">Total</td>
            <td><?php echo number_format($grandTotal, 2); ?></td>
        </tr>
    </table>
    <br>
    <a href="process_checkout.php">Selesai & Bayar</a>
</body>
</html>
