<!DOCTYPE html>
<html>
<head>
    <title>Login Aplikasi POS</title>
</head>
<body>
    <h2>Login Aplikasi POS</h2>
    <form action="proses_login.php" method="POST">
        <label>Username:</label><br>
        <input type="text" name="username" required><br><br>
        <label>Password:</label><br>
        <input type="password" name="password" required><br><br>
        <button type="submit">Login</button>
    </form>
</body>
</html>
