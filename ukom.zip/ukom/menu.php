<?php
session_start();
// Cek apakah user sudah login
if (!isset($_SESSION['username'])) {
    // Jika belum login, arahkan kembali ke login
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Menu Aplikasi POS</title>
</head>
<body>
    <h2>Selamat Datang di Aplikasi POS</h2>
    <p>Anda login sebagai: <?php echo $_SESSION['username']; ?></p>
    
    <ul>
        <li><a href="laporan_harian.php">Laporan Harian</a></li>
        <li><a href="laporan_bulanan.php">Laporan Bulanan</a></li>
        <li><a href="update_profile.php">Profil</a></li>
        <li><a href="add_product.php">Tambahkan produk</a></li>
        <li><a href="transaction.php">Transaksi</a></li>
    </ul>

    <a href="logout.php">Logout</a>
</body>
</html>
