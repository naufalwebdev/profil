<?php
session_start();
include 'koneksi.php';

// Pastikan user sudah login (session user_id ada)
if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('Anda harus login terlebih dahulu.'); window.location='login.php';</script>";
    exit;
}

$userId = $_SESSION['user_id'];

// Jika form disubmit (method POST), proses perubahan data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newUsername = trim($_POST['username']);
    $newPassword = trim($_POST['password']);

    // Validasi sederhana: minimal salah satu terisi
    if (empty($newUsername) && empty($newPassword)) {
        echo "<script>alert('Username atau password baru tidak boleh keduanya kosong!'); 
              window.location='update_profile.php';</script>";
        exit;
    }

    // Array penampung field yang akan diupdate
    $updates = [];

    // Jika user mengisi username
    if (!empty($newUsername)) {
        // Bisa ditambah validasi agar username unik, dsb.
        $updates[] = "username = '$newUsername'";
    }

    // Jika user mengisi password
    if (!empty($newPassword)) {
        // Hash password (disarankan gunakan password_hash() di aplikasi production)
        $hashedPassword = md5($newPassword);
        $updates[] = "password = '$hashedPassword'";
    }

    // Susun query hanya jika ada perubahan
    if (count($updates) > 0) {
        // Gabungkan field yang diupdate
        $sqlUpdate = "UPDATE users SET " . implode(', ', $updates) . " WHERE id = '$userId'";
        if ($koneksi->query($sqlUpdate) === TRUE) {
            // Berhasil update
            echo "<script>alert('Profil berhasil diupdate!'); window.location='update_profile.php';</script>";
        } else {
            // Gagal update
            echo "Terjadi kesalahan: " . $koneksi->error;
        }
    } else {
        // Tidak ada data di-update
        echo "<script>alert('Tidak ada perubahan yang dilakukan.'); window.location='update_profile.php';</script>";
    }
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Profil</title>
</head>
<body>
    <h2>Update Profil</h2>
    <form method="POST" action="">
        <label>Username Baru (opsional):</label><br>
        <input type="text" name="username" placeholder="Masukkan username baru"><br><br>

        <label>Password Baru (opsional):</label><br>
        <input type="password" name="password" placeholder="Masukkan password baru"><br><br>

        <button type="submit">Update Profil</button>
    </form>
    <br>
    <a href="index.php">Kembali ke Menu Utama</a>
</body>
</html>
