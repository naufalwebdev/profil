<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Register Akun</title>
</head>
<body>
    <h2>Register Akun Baru</h2>
    <form action="proses_register.php" method="POST">
        <label>Username:</label><br>
        <input type="text" name="username" required><br><br>
        <label>Password:</label><br>
        <input type="password" name="password" required><br><br>
        <input type="submit" value="Register">
    </form>
    <br>
    <a href="index.php">Kembali ke Halaman Login</a>
</body>
</html>
