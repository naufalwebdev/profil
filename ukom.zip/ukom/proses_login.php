<?php
session_start();
include 'koneksi.php';

// Ambil data dari form
$username = trim($_POST['username']);
$password = trim($_POST['password']);

// Contoh validasi sederhana: 
$password_md5 = md5($password); 

// Query untuk cek apakah ada user dengan username & password sesuai
$sql = "SELECT * FROM users WHERE username='$username' AND password='$password_md5' LIMIT 1";
$result = $koneksi->query($sql);

if ($result->num_rows > 0) {
    // Data cocok, login berhasil
    $row = $result->fetch_assoc();
    
    // Simpan informasi user ke SESSION
    $_SESSION['username'] = $row['username'];
    $_SESSION['user_id'] = $row['id'];
    // Arahkan ke halaman menu
    header("Location: menu.php");
    exit;
} else {
    // Login gagal, kembali ke halaman login
    echo "<script>alert('Username atau password salah!'); window.location='index.php';</script>";
}
?>
