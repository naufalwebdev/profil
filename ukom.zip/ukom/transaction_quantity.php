<?php
session_start();
if (!isset($_SESSION['selected_product'])) {
    header("Location: transaction.php");
    exit;
}

$product = $_SESSION['selected_product'];
?>
<!DOCTYPE html>
<html>
<head>
    <title>Jumlah Produk</title>
</head>
<body>
    <h2>Produk: <?php echo $product['name']; ?></h2>
    <p>Harga: <?php echo number_format($product['price'], 2); ?></p>
    <p>Stok Tersedia: <?php echo $product['stock']; ?></p>
    <form action="transaction_add_to_cart.php" method="POST">
        <label>Jumlah yang dibeli:</label><br>
        <input type="number" name="quantity" min="1" max="<?php echo $product['stock']; ?>" required>
        <button type="submit">Tambahkan ke Keranjang</button>
    </form>
    <br>
    <a href="transaction.php">Kembali</a>
</body>
</html>
