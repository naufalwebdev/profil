<?php
session_start();
include 'koneksi.php';

// Pastikan cart tidak kosong
if (!isset($_SESSION['cart']) || count($_SESSION['cart']) === 0) {
    echo "<script>alert('Keranjang masih kosong.'); window.location='transaction.php';</script>";
    exit;
}

// Hitung total
$grandTotal = 0;
foreach ($_SESSION['cart'] as $item) {
    $grandTotal += $item['price'] * $item['quantity'];
}

// -- Tahap 1: Tampilkan form bayar (uang yang diserahkan customer) jika belum disubmit
if (!isset($_POST['uang_bayar'])) {
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Pembayaran</title>
    </head>
    <body>
        <h2>Total Belanja: <?php echo number_format($grandTotal, 2); ?></h2>
        <form action="" method="POST">
            <label>Uang yang dibayarkan:</label><br>
            <input type="number" name="uang_bayar" required>
            <button type="submit">Bayar</button>
        </form>
        <br>
        <a href="transaction.php">Kembali</a>
    </body>
    </html>
    <?php
    exit;
}

// -- Tahap 2: Proses penyimpanan transaksi ke DB & perhitungan kembalian
$uangBayar = $_POST['uang_bayar'];

// Cek apakah uang cukup
if ($uangBayar < $grandTotal) {
    echo "<script>alert('Uang tidak cukup untuk membayar total belanja.'); window.location='process_checkout.php';</script>";
    exit;
}
$kembalian = $uangBayar - $grandTotal;

// Simpan data ke tabel transactions (header transaksi)
$now = date('Y-m-d H:i:s');
$sqlTrans = "INSERT INTO transactions (transaction_date, total) VALUES ('$now', '$grandTotal')";
if ($koneksi->query($sqlTrans) !== TRUE) {
    die("Gagal menyimpan transaksi: " . $koneksi->error);
}
$transactionID = $koneksi->insert_id; // Dapatkan ID transaksi yang baru disimpan

// Loop setiap item di cart, simpan ke transaction_details
foreach ($_SESSION['cart'] as $item) {
    $subTotal = $item['price'] * $item['quantity'];
    $productId = $item['id'];
    $qty = $item['quantity'];

    // Simpan detail
    $sqlDetail = "INSERT INTO transaction_details (transaction_id, product_id, quantity, sub_total)
                  VALUES ('$transactionID', '$productId', '$qty', '$subTotal')";
    if ($koneksi->query($sqlDetail) !== TRUE) {
        die("Gagal menyimpan detail: " . $koneksi->error);
    }

    // Kurangi stok produk
    $sqlUpdateStok = "UPDATE products SET stock = stock - $qty WHERE id = $productId";
    $koneksi->query($sqlUpdateStok);
}

// Bersihkan cart
unset($_SESSION['cart']);

?>
<!DOCTYPE html>
<html>
<head>
    <title>Struk Pembayaran</title>
</head>
<body>
    <h2>Transaksi Berhasil!</h2>
    <p>Total Belanja: <?php echo number_format($grandTotal, 2); ?></p>
    <p>Uang Pembayaran: <?php echo number_format($uangBayar, 2); ?></p>
    <p>Kembalian: <?php echo number_format($kembalian, 2); ?></p>
    <br>
    <a href="transaction.php">Transaksi Baru</a>
</body>
</html>
