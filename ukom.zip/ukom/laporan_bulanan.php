<?php
session_start();
include 'koneksi.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Laporan Bulanan</title>
</head>
<body>
    <h2>Laporan Bulanan</h2>

    <!-- 1. Form untuk memilih bulan -->
    <!-- Menggunakan input type="month" agar user mudah memilih bulan/tahun -->
    <form method="GET" action="">
        <label>Pilih Bulan Laporan:</label>
        <input type="month" name="bulan" 
               value="<?php echo isset($_GET['bulan']) ? $_GET['bulan'] : date('Y-m'); ?>" 
               required>
        <button type="submit">Tampilkan</button>
    </form>

    <?php
    // 2. Jika user sudah memilih bulan, lakukan query transaksi pada bulan tersebut
    if (isset($_GET['bulan'])) {
        $selectedMonth = $_GET['bulan']; // format: "YYYY-MM"

        // Query untuk mendapatkan semua transaksi pada bulan tersebut
        // DATE_FORMAT(transaction_date, '%Y-%m') hasilnya "YYYY-MM"
        $sql = "SELECT id, transaction_date, total
                FROM transactions
                WHERE DATE_FORMAT(transaction_date, '%Y-%m') = '$selectedMonth'
                ORDER BY transaction_date ASC";
        $result = $koneksi->query($sql);

        // 3. Tampilkan hasilnya dalam tabel
        if ($result && $result->num_rows > 0) {
            // Inisialisasi total pendapatan bulanan
            $totalPendapatanBulanan = 0;
            ?>

            <h3>Data Transaksi Bulan: <?php echo $selectedMonth; ?></h3>
            <table border="1" cellpadding="8" cellspacing="0">
                <tr>
                    <th>No</th>
                    <th>ID Transaksi</th>
                    <th>Tanggal Transaksi</th>
                    <th>Total</th>
                </tr>
                <?php
                $no = 1;
                while ($row = $result->fetch_assoc()) {
                    $idTransaksi = $row['id'];
                    $tglTransaksi = $row['transaction_date'];
                    $totalTransaksi = $row['total'];

                    // Tambahkan ke total pendapatan bulanan
                    $totalPendapatanBulanan += $totalTransaksi;
                    ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo $idTransaksi; ?></td>
                        <td><?php echo $tglTransaksi; ?></td>
                        <td><?php echo number_format($totalTransaksi, 2); ?></td>
                    </tr>
                    <?php
                }
                ?>
                <tr>
                    <td colspan="3" align="right"><strong>Total Pendapatan:</strong></td>
                    <td><strong><?php echo number_format($totalPendapatanBulanan, 2); ?></strong></td>
                </tr>
            </table>
            
            <!-- 4. Tombol Print -->
            <br>
            <button onclick="window.print()">Cetak Laporan</button>

            <?php
        } else {
            echo "<p>Tidak ada transaksi untuk bulan $selectedMonth.</p>";
        }
    }
    ?>

    <br>
    <a href="index.php">Kembali ke Menu Utama</a>
</body>
</html>
