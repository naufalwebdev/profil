<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['selected_product'])) {
    header("Location: transaction.php");
    exit;
}

$product = $_SESSION['selected_product'];
$quantity = $_POST['quantity'];

// Tambahkan ke cart
$cartItem = array(
    'id' => $product['id'],
    'plu' => $product['plu'],
    'name' => $product['name'],
    'price' => $product['price'],
    'quantity' => $quantity
);

// Simpan ke session cart
$_SESSION['cart'][] = $cartItem;

// Hapus selected_product karena sudah ditambahkan
unset($_SESSION['selected_product']);

// Kembali ke halaman transaction
header("Location: transaction.php");
exit;
