<?php
include 'koneksi.php';

// Mengambil data dari form dan menghapus spasi kosong
$username = trim($_POST['username']);
$password = trim($_POST['password']);

// Validasi sederhana
if(empty($username) || empty($password)){
    echo "Username dan password tidak boleh kosong!";
    exit;
}

// Periksa apakah username sudah terdaftar
$sql_check = "SELECT * FROM users WHERE username='$username'";
$result = $koneksi->query($sql_check);
if($result->num_rows > 0){
    echo "<script>alert('Username sudah terdaftar, silahkan pilih username lain!'); window.location='register.php';</script>";
    exit;
}

// Untuk keamanan, sebaiknya password di-hash terlebih dahulu.
// Contoh menggunakan MD5 (sederhana, namun sebaiknya gunakan password_hash() untuk aplikasi produksi)
$password_hash = md5($password);

// Menyimpan data ke tabel users
$sql = "INSERT INTO users (username, password) VALUES ('$username', '$password_hash')";
if($koneksi->query($sql) === TRUE){
    echo "<script>alert('Akun berhasil dibuat!'); window.location='index.php';</script>";
} else {
    echo "Terjadi kesalahan: " . $koneksi->error;
}

$koneksi->close();
?>
