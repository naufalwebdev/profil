<?php
session_start();
include 'koneksi.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Laporan Harian</title>
</head>
<body>
    <h2>Laporan Harian</h2>

    <!-- 1. Form untuk memilih tanggal laporan -->
    <form method="GET" action="">
        <label>Pilih Tanggal Laporan:</label>
        <input type="date" name="tanggal" 
               value="<?php echo isset($_GET['tanggal']) ? $_GET['tanggal'] : date('Y-m-d'); ?>" 
               required>
        <button type="submit">Tampilkan</button>
    </form>

    <?php
    // 2. Jika user sudah memilih tanggal, lakukan query transaksi pada tanggal tersebut
    if (isset($_GET['tanggal'])) {
        $selectedDate = $_GET['tanggal'];

        // Query untuk mendapatkan semua transaksi pada tanggal tersebut
        // Pastikan kolom transaction_date tersimpan dalam format date/datetime yang valid.
        $sql = "SELECT id, transaction_date, total
                FROM transactions
                WHERE DATE(transaction_date) = '$selectedDate'
                ORDER BY transaction_date ASC";
        $result = $koneksi->query($sql);

        // 3. Tampilkan hasilnya dalam tabel
        if ($result && $result->num_rows > 0) {
            // Inisialisasi total pendapatan harian
            $totalPendapatanHarian = 0;
            ?>

            <h3>Data Transaksi Tanggal: <?php echo $selectedDate; ?></h3>
            <table border="1" cellpadding="8" cellspacing="0">
                <tr>
                    <th>No</th>
                    <th>ID Transaksi</th>
                    <th>Tanggal Transaksi</th>
                    <th>Total</th>
                </tr>
                <?php
                $no = 1;
                while ($row = $result->fetch_assoc()) {
                    $idTransaksi = $row['id'];
                    $tglTransaksi = $row['transaction_date'];
                    $totalTransaksi = $row['total'];

                    // Tambahkan ke total pendapatan harian
                    $totalPendapatanHarian += $totalTransaksi;
                    ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo $idTransaksi; ?></td>
                        <td><?php echo $tglTransaksi; ?></td>
                        <td><?php echo number_format($totalTransaksi, 2); ?></td>
                    </tr>
                    <?php
                }
                ?>
                <tr>
                    <td colspan="3" align="right"><strong>Total Pendapatan:</strong></td>
                    <td><strong><?php echo number_format($totalPendapatanHarian, 2); ?></strong></td>
                </tr>
            </table>
            
            <!-- 4. Tombol Print -->
            <br>
            <button onclick="window.print()">Cetak Laporan</button>

            <?php
        } else {
            echo "<p>Tidak ada transaksi untuk tanggal $selectedDate.</p>";
        }
    }
    ?>

    <br>
    <a href="index.php">Kembali ke Menu Utama</a>
</body>
</html>
